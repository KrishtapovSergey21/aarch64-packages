Trigger
==================

Members
--------------
.. autoclass:: iio.Trigger
   :members:
   :inherited-members:
