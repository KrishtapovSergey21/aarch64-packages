# Soapy SDR - vendor and platform neutral SDR support library.

## Build Status

![Build Status](https://github.com/pothosware/SoapySDR/actions/workflows/ci.yml/badge.svg)

## Documentation

* https://github.com/pothosware/SoapySDR/wiki

## Licensing information

Use, modification and distribution is subject to the Boost Software
License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
http://www.boost.org/LICENSE_1_0.txt)
