
# Note: InnoSetup is already installed on Azure images; so don't run this step
#       Running choco seems a bit slow; seems to save about 40-60 seconds here
#choco install InnoSetup

set PATH=%PATH%;"C:\Program Files (x86)\Inno Setup 6"
