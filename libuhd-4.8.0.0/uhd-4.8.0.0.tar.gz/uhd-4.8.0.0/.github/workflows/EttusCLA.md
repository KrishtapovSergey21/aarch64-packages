# UHD Contributor License Agreement

Please find the full CLA text [here](https://files.ettus.com/licenses/Ettus_CLA.pdf).

By signing the pull request with the words "I have read the CLA Document and I
hereby sign the CLA" you agree to the terms of the document above. You do not
have sign the PDF itself, or send it by mail/fax/email if you sign it on GitHub.

If you prefer signing by mail/email/fax, please contact us under the address
in the document linked above.
