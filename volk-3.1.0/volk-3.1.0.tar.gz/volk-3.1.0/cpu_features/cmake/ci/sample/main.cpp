#include <iostream>

#include "cpuinfo_x86.h"

using namespace cpu_features;

int main(int /*argc*/, char** /*argv*/) {
  static const X86Features features = GetX86Info().features;
  std::cout << std::endl;
  return 0;
}
